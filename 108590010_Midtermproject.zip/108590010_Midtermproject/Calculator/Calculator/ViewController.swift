import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var equalButton: UIButton!
    @IBOutlet weak var dotButton: UIButton!
    @IBOutlet var numberButtons: [UIButton]!
    
    @IBOutlet var calculators: [UIButton]!
    @IBOutlet weak var result: UILabel!
    var newCalculation: Bool = false
    
    @IBOutlet weak var formula: UILabel!
    var buttonColor3: Bool = false
    var buttonColor4: Bool = false
    var buttonColor5: Bool = false
    var buttonColor6: Bool = false
    
    var output: Double = 0.0
    var sentence
    : String = ""{
        didSet{
            if((sentence
                    .contains("+") || sentence
                    .contains("-") || sentence
                    .contains("/") || sentence
                    .contains("*") ) && !sentence
                .isEmpty)
            {
                calculators[0].setTitle("C", for: UIControl.State.normal)
            }
            else if( true || sentence
                        .first == ("-")){
                calculators[0].setTitle("AC", for: UIControl.State.normal)
            }
            if(sentence
               == "inf"){
                sentence
                = "0"
                result.text! = "0"
            }
            
            updateButton(sentence
                         : sentence
            )
            formula.text! = sentence
            
        }
    }
    var decimal: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        result.text = "0"
        
        for i in 0...9{
            setCornerRadius(button: numberButtons[i])
        }
        
        for i in 0...6{
            setCornerRadius(button: calculators[i])
        }
        
        setCornerRadius(button: dotButton)
        setCornerRadius(button: equalButton)
    }
    
    func setCornerRadius(button: UIButton){
        button.clipsToBounds = true
        button.layer.cornerRadius = 30
    }
    
    @IBAction func numberClick(_ sender: UIButton) {
        let inputNumber = sender.tag-1
        if sentence
            .last == "."{
            decimal = true
        }
        if result.text == "0"{
            result.text = String(inputNumber)
            sentence
            += String(inputNumber)
        }else{
            result.text! += String(inputNumber)
            sentence
            += String(inputNumber)
        }
    }
    
    func equalClick(sentence
                    :String) -> Bool {
        if (sentence
                .last == "+" || sentence
                .first == ("-") || sentence
                .last == "-" || sentence
                .last == "/" || sentence
                .last == "*") {
            return true
        }
        else{
            return false
        }
    }
    
    func updateButton(sentence
                      :String) {
        let button3 = calculators[3]
        let button4 = calculators[4]
        let button5 = calculators[5]
        let button6 = calculators[6]
        if (sentence
                .last == "/") {
            button3.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if (sentence
                    .last == "*") {
            button4.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }else if (sentence
                    .last == "-") {
            button5.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else if (sentence
                    .last == "+") {
            button6.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
        else{
            button3.backgroundColor = #colorLiteral(red: 1, green: 0.5836493373, blue: 0.009624032304, alpha: 1)
            button4.backgroundColor = #colorLiteral(red: 1, green: 0.5836493373, blue: 0.009624032304, alpha: 1)
            button5.backgroundColor = #colorLiteral(red: 1, green: 0.5836493373, blue: 0.009624032304, alpha: 1)
            button6.backgroundColor = #colorLiteral(red: 1, green: 0.5836493373, blue: 0.009624032304, alpha: 1)
        }
    }
    
    @IBAction func calculatorClick(_ sender: UIButton) {
        let origText = result.text // if always number
        result.text  = ""
        
        if sentence
            == ""{
            sentence
            = "0"
        }else {
            if decimal == false{
                sentence
                += ""
            }
        }
        
        switch sender.tag{
            // AC
        case 0:
            if result.text == "0" {
                sentence
                = "0"
            }
            if( sentence
                    .first == ("-")){
                sentence
                    .removeAll()
            }
            
            else if((sentence
                        .contains("+") || sentence
                        .contains("-") || sentence
                        .contains("/") || sentence
                        .contains("*")) && !sentence
                        .isEmpty)
            {
                sentence
                    .removeLast()
            }
            else{
                sentence
                    .removeAll()
            }
            
            // +/-
        case 1:
            if let origText = origText{
                if origText.contains("-"){
                    result.text = origText.replacingOccurrences(of: "-", with: "")
                }else if origText == "0"{
                    result.text = "0"
                }else if origText != ""{
                    result.text = "-" + origText
                }
            }
            sentence
            +=  "*-1"
            
            // %
        case 2:
            sentence
            += "*0.01"
            let expression = NSExpression(format: sentence
            )
            output = expression.expressionValue(with: nil, context: nil) as! Double
            result.text = setStringFormat(output: output, decimal: 7 )
            var outputresult = String(output)
            while(outputresult.last == "0" || outputresult.last == "."){
                outputresult.removeLast()
                print(outputresult)
            }
            sentence
            = String(outputresult)
            decimal = true
  
            // /
        case 3:
            if equalClick(sentence
                          : sentence
            ) {
                sentence
                    .removeLast()
            }
            sentence
            += "/"
            
            // *
        case 4:
            if equalClick(sentence
                          : sentence
            ) {
                sentence
                    .removeLast()
            }
            sentence
            += "*"
            
            // -
        case 5:
            if equalClick(sentence
                          : sentence
            ) {
                sentence
                    .removeLast()
            }
            sentence
            += "-"
            
            // +
        case 6:
            if equalClick(sentence
                          : sentence
            ) {
                sentence
                    .removeLast()
            }
            sentence
            += "+"
            
            
        default:
            result.text = "Warning!!!"
            break
        }
        
        decimal = false
    }
    
    @IBAction func dotClick(_ sender: UIButton) {
        let origText = result.text
        
        if let origText = origText {
            if !origText.contains("."){
                sentence
                += "."
                result.text! += "."
                decimal = true
            }
        }
    }
    
    @IBAction func EqualClick(_ sender: UIButton) {
        if decimal == false{
            sentence
            += ".0"
        }
        
        let expression = NSExpression(format: sentence
        )
        output = expression.expressionValue(with: nil, context: nil) as! Double
        
        result.text = setStringFormat(output: output, decimal: 7 )
        var outputresult = String(output)
        while(outputresult.last == "0" || outputresult.last == "."){
            outputresult.removeLast()
            print(outputresult)
        }
        sentence
        = String(outputresult)
        decimal = true
    }
    
    func setStringFormat(output:Double, decimal:Int) -> String{
        if output.truncatingRemainder(dividingBy: 1.0) == 0{
            return String(format: "%.0f", output)
        }
        let numOfDigit = pow(10.0, Double(decimal))
        return String((output * numOfDigit).rounded(.toNearestOrAwayFromZero)/numOfDigit)
    }
    
}
